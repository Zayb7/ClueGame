import java.util.*;


public class IntBoard {

	//variables
	private final int TOTAL_ROWS = 4;
	private final int TOTAL_COLS = 4;
	
	//Constructor
	public IntBoard() {
		super();
		// TODO constructor stub
	}
	
	//methods
	public void calcAdjacencies(){
		
		
	}
	
	public LinkedList<Integer> getAdjList(int index){
		return new LinkedList<Integer>();
	}
	
	public void startTargets(int index, int steps){
		
	}
	
	public Set getTargets(){
		return new HashSet();
	}
	
	
	public int calcIndex(int row, int col){
//		if(row > TOTAL_ROWS || row < 0 || col > TOTAL_COLS || col < 0){
//			System.out.println("The row or column is out of bounds.");
//		}
//		
//		return row*TOTAL_COLS + col;
		
		return 0;
	}

	
}
